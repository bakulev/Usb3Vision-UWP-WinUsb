﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hjg.Pngcs.Zlib {
    // DEFLATE compression strategy
    public enum EDeflateCompressStrategy {
        Filtered,
        Huffman,
        Default
    }
}
