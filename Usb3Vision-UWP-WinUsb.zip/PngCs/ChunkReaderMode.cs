﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ar.Com.Hjg.Pngcs
{
    enum ChunkReaderMode
    {
        BUFFER,PROCESS,SKIP
    }
}
